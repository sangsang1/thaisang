<div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
            <div class="modal-dialog modal-sm">

                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="Login">Đăng Nhập</h4>
                    </div>
                    <div class="modal-body">
                        <form action="dangnhap" method="post">
                        <?php echo e(csrf_field()); ?> 
                            <div class="form-group">
                                <input type="text" class="form-control" id="username" name="email" placeholder="email">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" id="password"  name="password" placeholder="password">
                            </div>

                            <p class="text-center">
                                <button class="btn btn-template-main"><i class="fa fa-sign-in" name="dangnhap"></i> Đăng Nhập</button>
                            </p>
                            <a href="<?php echo e(url('/auth/redirect/facebook')); ?>" class="external facebook" data-animate-hover="pulse"><i class="fa fa-facebook"></i></a>
                        </form>

                        <p class="text-center text-muted">Bạn chưa đăng ký ?</p>
                        <p class="text-center text-muted"><a href="dangky"><strong>Đăng Ký Ngay</strong></a></p>

                    </div>
                </div>
            </div>
        </div><?php /**PATH F:\xampp\htdocs\Mobile\resources\views/auth/login.blade.php ENDPATH**/ ?>