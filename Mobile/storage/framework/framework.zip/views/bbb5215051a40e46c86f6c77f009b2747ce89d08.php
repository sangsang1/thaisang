
<?php $__env->startSection('content'); ?>
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="card-box table-responsive">
                                    <h4 class="m-t-0 header-title">SẢN PHẨM > SỬA</h4>
                                    
        <div class="col-lg-7" style="padding-bottom:120px">
				<?php if(count($errors)>0): ?>
				<div class="alert alert-danger">
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo e($err); ?>

					<br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<?php endif; ?>
				<form action="admin/sanpham/sua/<?php echo e($sanpham->id); ?>" method="POST" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

					<div class="form-group">
						<label>Tên</label>
						<input  class="form-control"  name="ten" value="<?php echo e($sanpham->Ten); ?>" placeholder="nhập tên sản phẩm " />
					</div>
					<div class="form-group">
						<label>Tóm tắt</label>
						<textarea id ="demo" class="form-control ckeditor"  name="tomtat" /><?php echo e($sanpham->TomTat); ?></textarea>
					</div>
					<div class="form-group">
						<label>Cấu hình</label>
						<textarea id ="demo" class="form-control ckeditor"  name="cauhinh" /><?php echo e($sanpham->CauHinh); ?></textarea>
					</div>
					<div class="form-group">
						<label>Giá</label>
						<input  class="form-control" value="<?php echo e($sanpham->Gia); ?>"  name="gia" placeholder="nhập giá sản phẩm " />
					</div>
					<div class="form-group">
						<label>Số lượng</label>
						<input  class="form-control" value="<?php echo e($sanpham->SoLuong); ?>" name="soluong" placeholder="nhập số lượng sản phẩm " />
					</div>
					<div class="form-group">
						<label>Hình</label>
						<input type="file" class="form-control" value="" name="hinh" placeholder="nhập hình ảnh " />
						<img width="100px" height="100px" src="images/sanpham/<?php echo e($sanpham->Hinh); ?>" >
					</div>
					<div class="form-group">
						<label>Nội dung</label>
						<textarea id ="demo" class="form-control ckeditor"  name="noidung" /><?php echo e($sanpham->NoiDung); ?></textarea>
					</div>
					<div class="form-group">
						<label>Bán chạy</label>
						<label class="radio-inline">
							<input
							<?php if($sanpham->BanChay==1): ?>
							<?php echo e('checked'); ?>

							<?php endif; ?>
							 name="banchay" value="1" checked="" type="radio">có
						</label>
						<label class="radio-inline">
							<input
							<?php if($sanpham->BanChay==0): ?>
							<?php echo e('checked'); ?>

							<?php endif; ?>
							name="banchay" value="0" type="radio">Không
						</label>
					</div>
					<div class="form-group">
						<label>Trạng thái</label>
						<label class="radio-inline">
							<input
							<?php if($sanpham->TrangThai==1): ?>
							<?php echo e('checked'); ?>

							<?php endif; ?>
							 name="trangthai" value="1" checked="" type="radio">Hiện
						</label>
						<label class="radio-inline">
							<input 
							<?php if($sanpham->TrangThai==0): ?>
							<?php echo e('checked'); ?>

							<?php endif; ?>
							name="trangthai" value="0" type="radio">Ẩn
						</label>
					</div>
					<div class="form-group">
						<label>Thể loại</label>
						<select class="form-control" name="theloai" id="quantri">
							<?php $__currentLoopData = $theloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option
							<?php if($sanpham->idTL==$tl->id): ?>
							<?php echo e('selected'); ?>

							<?php endif; ?>
							 value="<?php echo e($tl->id); ?>"><?php echo e($tl->Ten); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					<button type="submit" class="btn btn-default">Sửa</button>
					<button type="reset" class="btn btn-default">Huỷ</button>
					<form>
					</div>
				</div>
				<!-- /.row -->
			</div>
			<!-- /.container-fluid -->
		</div>     


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Mobile\resources\views/admin/sanpham/sua.blade.php ENDPATH**/ ?>