
<?php $__env->startSection('content'); ?>
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="card-box table-responsive">
                                    <h4 class="m-t-0 header-title">DANH SÁCH</h4>

        <div class="col-lg-7" style="padding-bottom:120px">
				<?php if(count($errors)>0): ?>
				<div class="alert alert-danger">
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo e($err); ?>

					<br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<?php endif; ?>
				<form action="admin/donhang/xulydonhang/<?php echo e($donhang->id); ?>" method="POST" >
					<?php echo e(csrf_field()); ?>

					<div class="form-group">
						<label>TongTien</label>
						<input  class="form-control" disabled="true"  name="tongtien" value="<?php echo e($donhang->TongTien); ?>" />
					</div>
					<div class="form-group">
						<label>GhiChu</label>
						<textarea name="ghichi" class="form-control" disabled="true" id="" cols="30" rows="10"><?php echo e($donhang->GhiChu); ?></textarea>
					</div>
					<div class="form-group">
						<label>Trạng thái</label>
						<select class="form-control" name="trangthai" id="trangthai">
							
							<?php if($donhang->TrangThai==0): ?>
							
								<option 
								<?php if($donhang->TrangThai==0): ?>
								<?php echo e('selected'); ?>

								<?php endif; ?>
								value="0">Chưa xử lý</option>
								<option
								<?php if($donhang->TrangThai==1): ?>
								<?php echo e('selected'); ?>

								<?php endif; ?>
								value="1">Đã xử lý</option>
								<option 
								<?php if($donhang->TrangThai==2): ?>
								<?php echo e('selected'); ?>

								<?php endif; ?>
								value="2">Đang giao hàng</option>
								<option 
								<?php if($donhang->TrangThai==3): ?>
								<?php echo e('selected'); ?>

								<?php endif; ?>
								value="3">Đã giao hàng</option>
								<option
								<?php if($donhang->TrangThai==4): ?>
								<?php echo e('selected'); ?>

								<?php endif; ?>
								value="4">Huỷ</option>
							
							<?php elseif($donhang->TrangThai==1): ?>
							
								<option
								<?php if($donhang->TrangThai==1): ?>
								<?php echo e('selected'); ?>

								<?php endif; ?>
								value="1">Đã xử lý</option>
								<option 
								<?php if($donhang->TrangThai==2): ?>
								<?php echo e('selected'); ?>

								<?php endif; ?>
								value="2">Đang giao hàng</option>
								<option 
								<?php if($donhang->TrangThai==3): ?>
								<?php echo e('selected'); ?>

								<?php endif; ?>
								value="3">Đã giao hàng</option>
							
							<?php elseif($donhang->TrangThai==2): ?>
							
								<option
								<?php if($donhang->TrangThai==2): ?>
								<?php echo e('selected'); ?>

								<?php endif; ?>
								value="2">Đang giao hàng</option>
								<option 
								<?php if($donhang->TrangThai==3): ?>
								<?php echo e('selected'); ?>

								<?php endif; ?>
								value="3">Đã giao hàng</option>
							
							<?php elseif($donhang->TrangThai==3): ?>
							
								<option
								<?php if($donhang->TrangThai==3): ?>
								<?php echo e('selected'); ?>

								<?php endif; ?>
								value="3">Đã giao hàng</option>
							
							<?php elseif($donhang->TrangThai==4): ?>
							
								<option
								<?php if($donhang->TrangThai==4): ?>
								<?php echo e('selected'); ?>

								<?php endif; ?>
								value="4">Huỷ</option>

							<?php endif; ?>
						</select>
					</div>
					<button type="submit" class="btn btn-default">Sửa</button>
					<button type="reset" class="btn btn-default">Huỷ</button>
					<form>
					</div>
				</div>
				<!-- /.row -->
			</div>
			<!-- /.container-fluid -->
		</div>                            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Mobile\resources\views/admin/donhang/xulydonhang.blade.php ENDPATH**/ ?>