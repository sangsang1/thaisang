
<?php $__env->startSection('content'); ?>
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="card-box table-responsive">
                                    <h4 class="m-t-0 header-title">DANH SÁCH</h4>
			<div class="clearfix"></div>
			<!-- /.col-lg-12 -->
			<?php if(session('ThongBao')): ?>
			<div class="alert alert-info">
				<?php echo e(session('ThongBao')); ?>

			</div>
			<?php endif; ?>
			<div class="clearfix"></div>
			<table class="table table-striped table-bordered table-hover" id="dataTables-example">
				<thead>
					<tr align="center">
						<th>ID</th>
						<th>Sim</th>
						<th>Dung lượng</th>
						<th>Màu sắc</th>
						<th>Ram</th>
						<th>Xoá</th>
						<th>Sửa</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $thuoctinh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="odd gradeX" align="center">
						<td><?php echo e($tt->id); ?></td>
						<td><?php echo e($tt->Sim); ?></td>
						<td><?php echo e($tt->DungLuong); ?></td>
						<td><?php echo e($tt->MauSac); ?></td>
						<td><?php echo e($tt->Ram); ?></td>
						<td class="center"><i class="fa fa-pencil  fa-fw"></i><a href="admin/thuoctinh/sua/<?php echo e($tt->id); ?>"> Sửa</a></td>
						<td class="center"><i class="fa fa-trash-o fa-fw"></i> <a href="admin/thuoctinh/xoa/<?php echo e($tt->id); ?>">Xoá</a></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
		<!-- /.row -->
	</div>
	<!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Mobile\resources\views/admin/thuoctinh/danhsach.blade.php ENDPATH**/ ?>