
<?php $__env->startSection('content'); ?>
<style>
    .product  {height:400px}
    .product .image .img-responsive {margin:auto;margin-top:20px;height:180px}
    .product .text h3 {height:32px; overflow:hidden; margin:15px;}


</style>
<section class="bar background-white">
            <div class="container">
                <div class="col-md-12">


                    <div class="row">
                        <div class="col-md-4">
                            <div class="box-simple">
                                <div class="icon">
                                    <i class="fa fa-desktop"></i>
                                </div>
                                <h3>CAM KẾT</h3>
                                <p>Chất lượng máy chính hãng.<br/>Sản phẩm đúng tiêu chuẩn với chất lượng tốt nhất.</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="box-simple">
                                <div class="icon">
                                    <i class="fa fa-print"></i>
                                </div>
                                <h3>ĐẢM BẢO</h3>
                                <p>Giá tốt nhất thị trường. <br/> Hoàn tiền nếu có nơi nào giá thấp hơn.</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="box-simple">
                                <div class="icon">
                                    <i class="fa fa-globe"></i>
                                </div>
                                <h3>BẢO HÀNH</h3>
                                <p>Tận tâm, Uy tín, Tiết kiệm. <br/>Một đổi một trong 15 ngày nếu xảy ra lỗi do NSX.</p>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="box-simple">
                                <div class="icon">
                                    <i class="fa fa-lightbulb-o"></i>
                                </div>
                                <h3>GIAO HÀNG</h3>
                                <p>Giao hàng trong phạm vi toàn quốc. <br/>Thời gian giao hàng từ 1 đến 4 ngày.</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="box-simple">
                                <div class="icon">
                                    <i class="fa fa-envelope-o"></i>
                                </div>
                                <h3>TRẢ GÓP</h3>
                                <p>Trả góp với lãi suất ưu đãi. <br/>Thủ tục đơn giản, nhanh chóng, thuận tiện.</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="box-simple">
                                <div class="icon">
                                    <i class="fa fa-user"></i>
                                </div>
                                <h3>HỖ TRỢ KỸ THUẬT</h3>
                                <p>Đội ngũ kỹ thuật chuyên nghiệp, tậm tâm.<br/> Phục vụ khách hàng mọi toàn thời gian 24/7</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="bar background-pentagon no-mb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="heading text-center">
                            <h2>Sản Phẩm Mới</h2>
                        </div>

                      
                        <!-- *** TESTIMONIALS CAROUSEL ***
 _________________________________________________________ -->
 <div class="row">

                   <?php $__currentLoopData = $sanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-2 col-sm-6">
                        <div class="product">
                            <div class="image">
                                <a href="chitietsanpham/<?php echo e($sp->id); ?>/<?php echo e($sp->Ten_KhongDau); ?>.html">
                                    <img src="images/sanpham/<?php echo e($sp->Hinh); ?>" alt="" class="img-responsive image1">
                                </a>
                            </div>
                            <!-- /.image -->
                            <div class="text">
                                <h3><a href="shop-detail.html"><?php echo e($sp->Ten); ?></a></h3>
                                <p class="price"><?php echo e(formatPrice($sp->Gia)); ?></p>
                                <div class="add-to-cart text-center">
                                    <a href="themgiohang/<?php echo e($sp->id); ?>">Thêm giỏ hàng</a>
                                 </div>  
                                <p class="buttons">
                                    <a href="shop-detail.html" class="btn btn-default">View detail</a>
                                </p>
                            </div>
                            <!-- /.text -->
                        </div>

                 
                        <!-- /.product -->
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
             
                   

                    </div>
                     
                        <!-- /.owl-carousel -->

                        <!-- *** TESTIMONIALS CAROUSEL END *** -->
                    </div>

                </div>
            </div>
        </section>

        <section class="bar background-image-fixed-2 no-mb color-white text-center">
            <div class="dark-mask"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="icon icon-lg"><i class="fa fa-file-code-o"></i>
                        </div>
                        <h3 class="text-uppercase">BẠN CÓ MUỐN TRẢI NGHIỆM DÙNG THỬ ĐIỆN THOẠI MỚI?</h3>
                        <p class="lead">Chúng tôi chờ đợi bạn,chào mừng đến với cửa hàng và thử nghiệm các sản phẩm mới nhất hoàn toàn miễn phí trong 7 ngày</p>
                        <p class="text-center">
                            <a href="index2.html" class="btn btn-template-transparent-black btn-lg">Liên hệ với chúng tôi</a>
                        </p>
                    </div>

                </div>
            </div>
        </section>

        <section class="bar background-white no-mb">
            <div class="container">

                <div class="col-md-12">
                    <div class="heading text-center">
                        <h2>Thông Tin Từ Cửa Hàng</h2>
                    </div>

                    <p class="lead">Các tin tức công nghệ, hướng dẫn sử dụng, giới thiệu điện thoại, tin tức khuyến mãi từ hệ thống cửa hàng của chúng tôi sẽ được publish thường xuyên vào đây để thông tin và hỗ trợ quý vi
                    </p>

                    <!-- *** BLOG HOMEPAGE ***
_________________________________________________________ -->

                    <div class="row">

                    <?php $__currentLoopData = $tintuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 col-sm-6">
                            <div class="box-image-text blog">
                                <div class="top">
                                    <div class="image">
                                        <img src="images/tintuc/<?php echo e($tt->Hinh); ?>" alt="" class="img-responsive">
                                    </div>
                                    <div class="bg"></div>
                                   
                                </div>
                                <h4><a href="blog-post.html"><?php echo e($tt->TieuDe); ?></a></h4>
                                <div class="content" style="text-align:left">
                                    
                                    <span class="meta-date">
											<time
                                                datetime="2015-08-11T06:27:49+00:00">
												<i class="fa fa-clock-o"> Thời Gian:</i><?php echo e(date( 'd/m/Y', strtotime($tt->created_at) )); ?>

											</time>
									</span><br>
                                    <span >
											<i class="fa fa-user"></i>Người Đăng:<?php echo e($tt->quantri->HoTen); ?><br>
                                            
									</span>
                                       
                                    
                                    <p class="read-more"><a href="blog-post.html" class="btn btn-template-main"> Đọc Thêm</a>
                                    </p>
                                </div>
                            </div>
                            <!-- /.box-image-text -->

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
                   

                    </div>
                    <!-- /.row -->

                    <!-- *** BLOG HOMEPAGE END *** -->

                </div>

            </div>
            <!-- /.container -->
        </section>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Mobile\resources\views/pages/trangchu.blade.php ENDPATH**/ ?>