<footer id="footer">
            <div class="container">
                <div class="col-md-3 col-sm-6">
                    <h4>Về Chúng Tôi</h4>

                    <p>Chuyên kinh doanh điện thoại di động, hàng công nghệ, linh kiện – phụ kiện điện thoại di động, sửa chữa điện thoại di động</p>

                    <hr>

                    <h4>Nhận thông tin từ chúng tôi</h4>

                    <form>
                        <div class="input-group">

                            <input type="text" class="form-control">

                            <span class="input-group-btn">

                        <button class="btn btn-default" type="button"><i class="fa fa-send"></i></button>

                    </span>

                        </div>
                        <!-- /input-group -->
                    </form>

                    <hr class="hidden-md hidden-lg hidden-sm">

                </div>
                <!-- /.col-md-3 -->

              
                <!-- /.col-md-3 -->

                <div class="col-md-3 col-sm-6">

                    <h4>Liên hệ</h4>

                    <p><strong>Shop Điện Thoại Sang </strong>
                    <br>30/4/1/5 QL50 <br>Bình Hưng Bình chánh <br>Thành phố Hồ Chí Minh
                    <br>Việt Nam <br> <strong>Mời quý khách</strong>
                    </p>


                    <a href="contact.html" class="btn btn-small btn-template-main">Liên hệ </a>

                    <hr class="hidden-md hidden-lg hidden-sm">

                </div>
                <!-- /.col-md-3 -->



                <div class="col-md-6 col-sm-6">

                    <h4>Photostream</h4>

                    <div class="photostream">
                        <div>
                            <a href="#">
                                <img src="img/detailsquare.jpg" class="img-responsive" alt="#">
                            </a>
                        </div>
                        <div>
                            <a href="#">
                                <img src="img/detailsquare2.jpg" class="img-responsive" alt="#">
                            </a>
                        </div>
                        <div>
                            <a href="#">
                                <img src="img/detailsquare3.jpg" class="img-responsive" alt="#">
                            </a>
                        </div>
                        <div>
                            <a href="#">
                                <img src="img/detailsquare3.jpg" class="img-responsive" alt="#">
                            </a>
                        </div>
                        <div>
                            <a href="#">
                                <img src="img/detailsquare2.jpg" class="img-responsive" alt="#">
                            </a>
                        </div>
                        <div>
                            <a href="#">
                                <img src="img/detailsquare.jpg" class="img-responsive" alt="#">
                            </a>
                        </div>
                    </div>

                </div>
                <!-- /.col-md-3 -->
            </div>
            <!-- /.container -->
        </footer><?php /**PATH F:\xampp\htdocs\Mobile\resources\views/layout/footer.blade.php ENDPATH**/ ?>