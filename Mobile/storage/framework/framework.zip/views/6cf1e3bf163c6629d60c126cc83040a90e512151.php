
<?php $__env->startSection('content'); ?>
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="card-box table-responsive">
                                    <h4 class="m-t-0 header-title">DANH SÁCH</h4>
        <div class="col-lg-7" style="padding-bottom:120px">
				<?php if(count($errors)>0): ?>
				<div class="alert alert-danger">
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo e($err); ?>

					<br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<?php endif; ?>
				<form action="admin/khuyenmai/them" method="POST">
					<?php echo e(csrf_field()); ?>

					<div class="form-group">
						<label>Tên</label>
						<input  class="form-control"  name="ten" placeholder="nhập tên " />
					</div>
					<div class="form-group">
						<label>NoiDung</label>
						<textarea id ="demo" class="form-control ckeditor"  name="noidung" /></textarea>
					</div>
					<div class="form-group">
						<label>Ngày Kết Thúc</label>
						<input type="text" class="datepicker form-control" name="ngayketthuc" placeholder="nhập ngày kết thúc " />
					</div>
					<div class="form-group">
						<label>Trạng thái</label>
						<label class="radio-inline">
							<input name="trangthai" value="1" checked="" type="radio">Hiện
						</label>
						<label class="radio-inline">
							<input name="trangthai" value="0" type="radio">Ẩn
						</label>
					</div>
					<div class="form-group">
						<label>Quản trị</label>
						<select class="form-control" name="quantri" id="quantri">
							<?php $__currentLoopData = $quantri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($qt->id); ?>"><?php echo e($qt->HoTen); ?>-<?php echo e($qt->Quyen); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					<button type="submit" class="btn btn-default">Thêm</button>
					<button type="reset" class="btn btn-default">Huỷ</button>
					<form>
					</div>
				</div>
				<!-- /.row -->
			</div>
			<!-- /.container-fluid -->
		</div>
		<?php $__env->stopSection(); ?>
		<?php $__env->startSection('script'); ?>
		<script>
			$(document).ready(function(e) {   
				$('.datepicker').bootstrapMaterialDatePicker({
					format: 'D/M/Y', 
					weekStart: 1, time: false
				}); 
			});
		</script>                            
           
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Mobile\resources\views/admin/khuyenmai/them.blade.php ENDPATH**/ ?>