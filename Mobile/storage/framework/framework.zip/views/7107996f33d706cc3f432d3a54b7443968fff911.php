
<?php $__env->startSection('content'); ?>
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="card-box table-responsive">
                                    <h4 class="m-t-0 header-title">DANH SÁCH</h4>

         <div class="clearfix"></div>
            <!-- /.col-lg-12 -->
            <?php if(session('ThongBao')): ?>
            <div class="alert alert-info">
                <?php echo e(session('ThongBao')); ?>

            </div>
            <?php endif; ?>
            <div class="clearfix"></div>
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <thead>
                    <tr align="center">
                        <th>ID</th>
                        <th>TongTien</th>
                        <th>Ghichu</th>
                        <th>Khachhang</th>
                        <th>Quantri</th>
                        <th>Trangthai</th>
                        <th>Delete</th>
                        <th>View</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $donhang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="odd gradeX" align="center">
                        <td><?php echo e($dh->id); ?></td>
                        <td><?php echo e(number_format($dh->TongTien)); ?></td>
                        <td><?php echo e($dh->GhiChu); ?></td>
                        <td><?php echo e($dh->khachhang->HoTen); ?></td>
                        <td><?php echo e($dh->quantri->HoTen); ?></td>
                        <td>
                           <a href="admin/donhang/xulydonhang/<?php echo e($dh->id); ?>" class="btn btn-xs 
                               <?php if($dh->TrangThai==0): ?>
                               <?php echo e('btn-danger'); ?>

                               <?php elseif($dh->TrangThai==4): ?>
                               <?php echo e('btn-danger'); ?>

                               <?php else: ?>
                               <?php echo e('btn-info'); ?>

                               <?php endif; ?>
                               ">
                               <?php if($dh->TrangThai==1): ?>
                               <?php echo e('Xu Ly'); ?>

                               <?php elseif($dh->TrangThai==2): ?>
                               <?php echo e('Dang giao hang'); ?>

                               <?php elseif($dh->TrangThai==3): ?>
                               <?php echo e('Da giao hang'); ?>

                               <?php elseif($dh->TrangThai==4): ?>
                               <?php echo e('Da huy'); ?>

                               <?php else: ?>
                               <?php echo e('Chua xu ly'); ?>

                               <?php endif; ?>

                           </a>
                       </td>
                       <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a href="admin/donhang/xoa/<?php echo e($dh->id); ?>" > Delete</a></td>
                       <td>
                          <a class="view" data-key=<?php echo e($dh->id); ?> >  
                            <i class="fa fa-eye"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <!-- /.row -->
    <div class="modal" id="myModal">
        <div class="modal-dialog">
          <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
              <h4 class="modal-title">Chi tiet hoa don #<b class="idhoadon" ></b></h4>
              <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>

          <!-- Modal body -->
          <div class="modal-body ">
              <table class="table table-striped table-bordered table-hover ketqua" id="dataTables-example">

              </table>
          </div>

          <!-- Modal footer -->
          <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          </div>

      </div>
  </div>
</div>

</div>
<!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $(".view").click(function(){
            var id=$(this).attr("data-key");
            $("#myModal").modal('show');
            $(".idhoadon").text(id);
            $.get("admin/ajax/chitietdonhang/"+id,function(data){
                $(".ketqua").html(data);
                            // alert(data);
                        });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Mobile\resources\views/admin/donhang/danhsach.blade.php ENDPATH**/ ?>