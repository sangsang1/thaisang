
<?php $__env->startSection('content'); ?>

<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="card-box table-responsive">
                                    <h4 class="m-t-0 header-title">DANH SÁCH</h4>
                                    

                                       
                                 <div class="clearfix"></div>
            <!-- /.col-lg-12 -->
            <?php if(session('ThongBao')): ?>
            <div class="alert alert-info">
                <?php echo e(session('ThongBao')); ?>

            </div>
            <?php endif; ?>
            <div class="clearfix"></div>
            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                <thead>
                    <tr align="center">
                        <th>ID</th>
                        <th>Ten</th>
                        <th>TrangChu</th>
                        <th>TrangThai</th>
                        <th>Xoá</th>
                        <th>Sửa</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $theloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="odd gradeX" align="center">
                        <td><?php echo e($tl->id); ?></td>
                        <td><?php echo e($tl->Ten); ?></td>
                        <td>
                            <a  href="admin/theloai/xuly/<?php echo e($tl->id); ?>" class="btn btn-xs 
                            <?php if($tl->TrangChu==1): ?> 
                                <?php echo e('btn-info'); ?>

                            <?php else: ?>
                                <?php echo e('btn-danger'); ?>

                            <?php endif; ?>;         
                        ">
                            <?php if($tl->TrangChu==1): ?>
                                <?php echo e('Hiển thị'); ?>

                            <?php else: ?>
                                <?php echo e('Không hiển thị'); ?>    
                            <?php endif; ?>
                        </td>
                        <td>
                            <a   class="btn btn-xs 
                            <?php if($tl->TrangThai==1): ?> 
                                <?php echo e('btn-info'); ?>

                            <?php else: ?>
                                <?php echo e('btn-danger'); ?>

                            <?php endif; ?>;         
                        ">
                            <?php if($tl->TrangThai==1): ?>
                                <?php echo e('Hiện'); ?>

                            <?php else: ?>
                                <?php echo e('Ẩn'); ?>    
                            <?php endif; ?>
                        </td>
                        <td class="center"><i class="fa fa-pencil  fa-fw"></i><a href="admin/theloai/sua/<?php echo e($tl->id); ?>"> Sửa</a></td>
                        <td class="center"><i class="fa fa-trash-o fa-fw"></i> <a href="admin/theloai/xoa/<?php echo e($tl->id); ?>">Xoá</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
                <footer class="footer text-right">
                    2020 - 2021  Admin Lương Thái Sang
                </footer>

            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Mobile\resources\views/admin/theloai/danhsach.blade.php ENDPATH**/ ?>