
<?php $__env->startSection('content'); ?>
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="card-box table-responsive">
                                    <h4 class="m-t-0 header-title">DANH SÁCH</h4>
            <div class="clearfix"></div>
			<!-- /.col-lg-12 -->
			<?php if(session('ThongBao')): ?>
			<div class="alert alert-info">
				<?php echo e(session('ThongBao')); ?>

			</div>
			<?php endif; ?>
			<div class="clearfix"></div>
			<table class="table table-striped table-bordered table-hover" id="dataTables-example">
				<thead>
					<tr align="center">
						<th>ID</th>
						<th>Email</th>
						<th>SoDienThoai</th>
						<th>HoTen</th>
						<th>Quyen</th>
						<th>Sửa</th>
						<th>Xoá</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $quantri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="odd gradeX" align="center">
						<td><?php echo e($qt->id); ?></td>
						<td><?php echo e($qt->Email); ?></td>
						<td><?php echo e($qt->SoDienThoai); ?></td>
						<td><?php echo e($qt->HoTen); ?></td>
						<td>
							<a  class="btn btn-xs btn-info">
							<?php if($qt->Quyen==1): ?>
								<?php echo e('QTTaiKhoan'); ?>

							<?php elseif($qt->Quyen==2): ?>
								<?php echo e('QTKinhDoanh'); ?>	
							<?php else: ?>
								<?php echo e('QTDanhMuc'); ?>

							<?php endif; ?>
						</td>
						<td class="center"><i class="fa fa-pencil  fa-fw"></i><a href="admin/quantri/sua/<?php echo e($qt->id); ?>"> Sửa</a></td>
						<td class="center"><i class="fa fa-trash-o fa-fw"></i> <a href="admin/quantri/xoa/<?php echo e($qt->id); ?>">Xoá</a></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
		<!-- /.row -->
	</div>
	<!-- /.container-fluid -->
</div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Mobile\resources\views/admin/quantri/danhsach.blade.php ENDPATH**/ ?>