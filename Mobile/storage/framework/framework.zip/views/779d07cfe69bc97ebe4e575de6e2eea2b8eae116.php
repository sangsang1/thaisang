
<?php $__env->startSection('content'); ?>
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="card-box table-responsive">
                                    <h4 class="m-t-0 header-title">DANH SÁCH</h4>
        	<div class="col-lg-7" style="padding-bottom:120px">
				<?php if(count($errors)>0): ?>
				<div class="alert alert-danger">
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo e($err); ?>

					<br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<?php endif; ?>
				<form action="admin/anhslidesanpham/sua/<?php echo e($anhslidesp->id); ?>" method="POST" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

					<div class="form-group">
						<label>Ảnh Trên</label>
						<input type="file" class="form-control" value="" name="anhtren" placeholder="nhập hình ảnh " />
						<img width="100px" height="100px" src="images/anhslidesp/<?php echo e($anhslidesp->AnhTren); ?>" alt="">
					</div>
					<div class="form-group">
						<label>Ảnh Dưới</label>
						<input type="file" class="form-control" value="" name="anhduoi" placeholder="nhập hình ảnh " />
						<img width="100px" height="100px" src="images/anhslidesp/<?php echo e($anhslidesp->AnhDuoi); ?>" alt="">
					</div>
					<div class="form-group">
                                <label>Sản phẩm</label>
                                <select class="form-control" name="sanpham" id="sanpham">
                                     <?php $__currentLoopData = $sanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
									<?php if($sp->id==$anhslidesp->idSP): ?>
									<?php echo e('seleted'); ?>

									<?php endif; ?>
                                     value="<?php echo e($sp->id); ?>"><?php echo e($sp->Ten); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
					<button type="submit" class="btn btn-default">Thêm</button>
					<button type="reset" class="btn btn-default">Huỷ</button>
					<form>
					</div>
				</div>
				<!-- /.row -->
			</div>
			<!-- /.container-fluid -->
		</div>                            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Mobile\resources\views/admin/anhslidesanpham/sua.blade.php ENDPATH**/ ?>