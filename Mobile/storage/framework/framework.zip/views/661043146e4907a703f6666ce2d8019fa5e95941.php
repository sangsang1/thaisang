
<?php $__env->startSection('content'); ?>
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="card-box table-responsive">
                                    <h4 class="m-t-0 header-title">DANH SÁCH > SỬA</h4>

                <div class="col-lg-7" style="padding-bottom:120px">
				<?php if(count($errors)>0): ?>
				<div class="alert alert-danger">
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo e($err); ?>

					<br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<?php endif; ?>
				<form action="admin/thuoctinh/them" method="POST">
					<?php echo e(csrf_field()); ?>

					<div class="form-group">
						<label>Sim</label>
						<input class="form-control" name="sim" placeholder="nhập số lượng sim" />
					</div>
					<div class="form-group">
						<label>Dung lượng</label>
						<input class="form-control" name="dungluong" placeholder="nhập dung lượng" />
					</div>
					<div class="form-group">
						<label>Màu sắc</label>
						<input class="form-control" name="mausac" placeholder="nhập màu sắc" />
					</div>
					<div class="form-group">
						<label>Ram</label>
						<input class="form-control" name="ram" placeholder="nhập ram" />
					</div>
					<button type="submit" class="btn btn-default">Thêm</button>
					<button type="reset" class="btn btn-default">Huỷ</button>
					<form>
					</div>
				</div>
				<!-- /.row -->
			</div>
			<!-- /.container-fluid -->
		</div>                   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Mobile\resources\views/admin/thuoctinh/them.blade.php ENDPATH**/ ?>