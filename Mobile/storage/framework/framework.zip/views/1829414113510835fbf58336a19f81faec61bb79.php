
<?php $__env->startSection('content'); ?>
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="card-box table-responsive">
                                    <h4 class="m-t-0 header-title">SẢN PHẨM</h4>

                <div class="clearfix"></div>
			<!-- /.col-lg-12 -->
			<?php if(session('ThongBao')): ?>
			<div class="alert alert-info">
				<?php echo e(session('ThongBao')); ?>

			</div>
			<?php endif; ?>
			<div class="clearfix"></div>
			<table class="table table-striped table-bordered table-hover" id="dataTables-example">
				<thead>
					<tr align="center">
						<th>ID</th>
						<th>Nội dung</th>
						<th>Tóm tắt </th>
						<th>Trạng thái</th>
						<th>Thể loại</th>
						<th>Xoá</th>
						<th>Sửa</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $sanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="odd gradeX" align="center">
						<td><?php echo e($sp->id); ?></td>
						<td>
							<?php echo e($sp->Ten); ?><br>
							<img width="100px" height="100px" src="images/sanpham/<?php echo e($sp->Hinh); ?>" ><br>
							Gia:<?php echo e($sp->Gia); ?><br>
							Soluong:<?php echo e($sp->SoLuong); ?>

						</td>
						<td><?php echo e($sp->TomTat); ?></td>
						<td>
							<a class="btn btn-xs
							<?php if($sp->TrangThai==1): ?>
							<?php echo e('btn-info'); ?>

							<?php else: ?>
							<?php echo e('btn-danger'); ?>

							<?php endif; ?>
							">
							<?php if($sp->TrangThai==1): ?>
							<?php echo e("Hiển thị"); ?>

							<?php else: ?>
							<?php echo e("Ẩn"); ?>

							<?php endif; ?>
						</td>
						<td>
							<?php echo e($sp->theloai->Ten); ?>

						</td>
						<td class="center"><i class="fa fa-pencil  fa-fw"></i><a href="admin/sanpham/sua/<?php echo e($sp->id); ?>"> Sửa</a></td>
						<td class="center"><i class="fa fa-trash-o fa-fw"></i> <a href="admin/sanpham/xoa/<?php echo e($sp->id); ?>">Xoá</a></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
		<!-- /.row -->
	</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Mobile\resources\views/admin/sanpham/danhsach.blade.php ENDPATH**/ ?>