
<?php $__env->startSection('content'); ?>
<div id="content">
            <div class="container">

                <div class="row">

				<?php if(session('ThongBao')): ?>
					<div class="alert alert-success">
					<?php echo e(session('ThongBao')); ?>

          </div>
          <?php endif; ?>

        	<?php if(session('mess')): ?>
					<div class="alert alert-danger">
					<?php echo e(session('mess')); ?>

          </div>
          <?php endif; ?>
        
        
                    <div class="col-md-12">
                        <p class="text-muted lead">You currently have 3 item(s) in your cart.</p>
                    </div>


                    <div class="col-md-9 clearfix" id="basket">

                        <div class="box">

                            <form method="post" >

                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th colspan="2">Sản Phẩm</th>
                                                <th>Số Lượng</th>
                                                <th>Đơn Giá</th>
                                                <th>Giá</th>
                                                <th colspan="2">Tổng Tiền</th>
                                            </tr>
										</thead>
									
                                        <tbody>
										<?php $stt=1; $sum=0; ?>
										<?php $__currentLoopData = $sanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a href="#">
                                                        <img src="images/sanpham/<?php echo e($sp->options->hinh); ?>" alt="White Blouse Armani">
                                                    </a>
                                                </td>
                                                <td><a href="#"><?php echo e($sp->name); ?></a>
                                                </td>
                                                <td>
												<input class="soluong" type="number" name="soluong" value="<?php echo e($sp->qty); ?>" min=0 style="width: 50px">
                    							<input type="hidden" name="idsp" class="idsp"  value="<?php echo e($sp->id); ?>" >
                                                </td>
                                                <td><?php echo e(number_format($sp->price)); ?></td>
                                                <td><?php echo e(number_format(($sp->price*$sp->qty))); ?></td>
												<td><?php echo e(number_format(($sp->price*$sp->qty))); ?></td>
												<td>
												<i class="fa fa-pencil  fa-fw " ></i><a class="updatecart" data-key=<?php echo e($key); ?>> Sửa</a> 
                                                <a href="xoagiohang/<?php echo e($key); ?>"><i class="fa fa-trash-o"></i>xoá</a>
                                                </td>
											</tr>
											<?php $stt++;$sum+=$sp->price*$sp->qty?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
										
                                        <tfoot>
                                            <tr>
                                                <th colspan="5">Total</th>
                                                <th colspan="2"><?php echo e(number_format($sum)); ?></th>
                                            </tr>
                                        </tfoot>
                                    </table>

                                </div>
                                <!-- /.table-responsive -->

                                <div class="box-footer">
                                    <div class="pull-left">
                                        <a href="trangchu" class="btn btn-default"><i class="fa fa-chevron-left"></i> Tiếp Tục Mua Sắm</a>
                                    </div>
                                    <div class="pull-right">
                                    <div class="pull-left">
                                        <a href="shopping/donhang" class="btn btn-default"><i class="fa fa-chevron-right"></i> Thanh Toán</a>
                                    </div>

                                    </div>
                                </div>
								
                            </form>

                        </div>
                        <!-- /.box -->

                       

                
                </div>

            </div>
            <!-- /.container -->
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
 

  $(document).ready(function(){
   $(".updatecart").click(function(){
      var soluong=$(this).parents("tr").find(".soluong").val();
      var idcart=$(this).attr("data-key");
      var idsp=$(this).parents("tr").find(".idsp").val();
      // alert(soluong);
      $.get("suagiohang/"+idcart+"/"+soluong+"/"+idsp+"/",function(data){
        $(".tien").append(data);
         if(data==1){
            alert("cap nhap thanh cong");
             location.reload();
           }else{
              alert("cap nhap that bai");
             location.reload();
           }
      });
   });
});
  
</script>
   

<?php $__env->stopSection(); ?>

<?php echo $__env->make("frontend.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\Mobile\resources\views/frontend/subpage/giohang.blade.php ENDPATH**/ ?>